// JavaScript Document
$(document).ready(function () {
    $('#openMenu').click(function () {
        $('#navbar').slideToggle();
    });
    AOS.init();
    $(document).scroll(function(){
        var scroll=$(document).scrollTop();
        var oTop = $('#counter').offset().top - window.innerHeight;
        var oBottom = $('#counter').offset().top + $('#counter').innerHeight();
        if (scroll > oTop && scroll < oBottom) {
            $('.counterValue').each(function() {
                var $this = $(this),
                    countTo = $this.attr('data-count');
                $({
                    countNum: $this.text()
                }).animate({
                        countNum: countTo
                    },
                    {
                        duration: 2000,
                        easing: 'swing',
                        step: function() {
                            $this.text(Math.floor(this.countNum));
                        },
                        complete: function() {
                            $this.text(this.countNum);
                            //alert('finished');
                        }

                    });
            });
        }
        var skillsTop = $('.skills').offset().top - window.innerHeight;
        var skillsEnd= $('.skills').offset().top + $('.skills').innerHeight();
        if(scroll > skillsTop && scroll < skillsEnd){
                $('.longBar').addClass('long');
                $('.shortBar').addClass('short');
        }else {
            $('.longBar').removeClass('long');
            $('.shortBar').removeClass('short');
        }
        if(scroll > 80) {
            $('#fixhead>section').addClass('background');
            $('#fixhead').css('top','0');
            $('#gotop').addClass('show');
        }else{
            if($(window).width()<750){
                $('#fixhead a').click(function(){
                    $('#navbar').slideUp();
                });
                $('#fixhead').css('top','0px');
            }else{
                $('#fixhead').css('top','60px');
            }
            $('#fixhead>section').removeClass('background');
            $('#gotop').removeClass('show');}

        $('#gotop').click(function(){

            $(document).scrollTop(0);

        });
    });
});