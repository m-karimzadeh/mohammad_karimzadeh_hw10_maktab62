const http = require('http');
const fs = require('fs');

const port = 3000;
let errPage;

try {
    errPage = fs.readFileSync(__dirname + '/pageFile/error.html', 'utf8')
} catch (err) {
    console.log('errPage read err');
}

function cssFilePatternCheck(path){
    let pattern = /.\.css$/;
    
    return pattern.test(path);
}

function fontFilePatternCheck(path){
    let pattern = /webfonts/;
    
    return pattern.test(path);
}

function jsFilePatternCheck(path){
    let pattern = /.\.js$/;
    
    return pattern.test(path);
}

function imageFilePatternCheck(path){
    let pattern = /([/|.|\w|\s|-])*\.(?:jpg|gif|png)/;
    
    return pattern.test(path);
}

http.createServer((req, res) => {

    if(req.method === 'GET'){
        if (req.url === '/') {
            fs.readFile(__dirname + '/pageFile/index.html', 'utf-8', (err, page) => {
                if (err) {
                    console.log(err);
                    res.end(errPage)

                } else {
                    res.end(page)
                }
            });

        }else if (cssFilePatternCheck(req.url) || jsFilePatternCheck(req.url)) {
            fs.readFile(__dirname + `/pageFile/${req.url}`, 'utf-8', (err, page) => {
                if (err) {
                    console.log(err);
                    res.end(errPage)

                } else {
                    res.end(page)
                }
            });

        }else if(imageFilePatternCheck(req.url) || fontFilePatternCheck(req.url)){
            let filePath = __dirname + `/pageFile/${req.url}`;

            fs.exists(filePath, function(response){
                if(response){
                    let readStream = fs.createReadStream(filePath);
                    
                    readStream.pipe(res);
            
                }else{
                    res.end('Page Not Found :((')
                }
            })

        }else{
            res.end('Page Not Found :((')
        }

    }else{
        res.end('Page Not Found :(')
    }

}).listen(port);



console.log(`server is running on port ${port}`);